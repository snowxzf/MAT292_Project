import pandas as pd
import ast
import re
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Dict, Any

def read_predictive_summary(file_path):
    """Reads a single predictive summary CSV file."""
    try:
        df = pd.read_csv(file_path, keep_default_na=True, na_values=['', 'None', 'nan', 'NaN'])
        
        if 'Method' in df.columns:
             df['Method'] = df['Method'].astype(str)
             
        return df
    except FileNotFoundError:
        print(f"Warning: Predictive file not found: {file_path}. Skipping.")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return pd.DataFrame()

def read_neuralode_results(allstats_file, mase_file):
    """
    Reads NeuralODE results from two log files and merges them.
    (This is the user-specified original parsing method.)
    """
    try:
        with open(allstats_file, 'r') as f: allstats_content = f.read()
        
        allstats_rows = []
        allstats_pattern = r'\[Patient-(\d+) Metrics \([^)]+\)\]:\s*MAE=[\d\.\-e]+,\s*Chi\^2=([+\-]?[\d\.\-e]+),\s*NSE=([+\-]?[\d\.\-e]+),\s*KGE=([+\-]?[\d\.\-e]+)'
        
        for match in re.finditer(allstats_pattern, allstats_content):
            try:
                p_id = int(match.group(1)); chi2 = float(match.group(2)); nse = float(match.group(3)); kge = float(match.group(4));
                allstats_rows.append({'Patient': p_id, 'Chi2': chi2, 'NSE': nse, 'KGE': kge})
            except ValueError: continue
        
        allstats_df = pd.DataFrame(allstats_rows)

        with open(mase_file, 'r') as f: mase_content = f.read()

        mase_rows = []
        mase_pattern = r'\[Patient-(\d+) Metrics \([^)]+\)\]:\s*MASE=([+\-]?[\d\.\-e]+|nan)'
        seen_ids = set()

        for match in re.finditer(mase_pattern, mase_content):
            try:
                p_id = int(match.group(1))
                if p_id in seen_ids: continue
                seen_ids.add(p_id)
                mase_str = match.group(2).lower()
                mase = float(mase_str) if mase_str != 'nan' else np.nan
                mase_rows.append({'Patient': p_id, 'MASE': mase})
            except ValueError: continue
        
        mase_df = pd.DataFrame(mase_rows)
        
        final_df = pd.merge(allstats_df, mase_df, on='Patient', how='outer')
        
        final_df['Method'] = 'NeuralODE'
        final_df['Overall_FitTime'] = np.nan
        final_df['Total_Convergence_Runtime'] = np.nan
        final_df['Strong_Error_Metric'] = np.nan
        final_df['Weak_Error_Metric'] = np.nan
        
        return final_df.dropna(subset=['MASE', 'Chi2', 'NSE', 'KGE'])

    except FileNotFoundError as e:
        print(f"Error: NeuralODE log file not found: {e}. Returning empty DataFrame.")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error processing NeuralODE files: {e}")
        return pd.DataFrame()


def load_all_data():
    em_df = read_predictive_summary('em_predictive_metrics_summary.csv')
    milstein_df = read_predictive_summary('milstein_predictive_metrics_summary.csv')
    srk_df = read_predictive_summary('srk_predictive_metrics_summary.csv')
    neuralode_df = read_neuralode_results('allstats.txt', 'MASEonly.txt')
    
    return pd.concat([em_df, milstein_df, srk_df, neuralode_df], ignore_index=True)


# --- 3. Feature Engineering and Cleanup ---

def prepare_analyzed_data(df):
    if 'FitTime' in df.columns: df.rename(columns={'FitTime': 'Overall_FitTime'}, inplace=True)
    if 'Runtime' in df.columns: df.rename(columns={'Runtime': 'Total_Convergence_Runtime'}, inplace=True)
    if 'StrongError' in df.columns: df.rename(columns={'StrongError': 'Strong_Error_Metric'}, inplace=True)
    if 'WeakError' in df.columns: df.rename(columns={'WeakError': 'Weak_Error_Metric'}, inplace=True)

    numeric_cols_final = [
        'MASE', 'Chi2', 'NSE', 'KGE', 'Overall_FitTime', 'Total_Convergence_Runtime', 
        'Strong_Error_Metric', 'Weak_Error_Metric', 'TrajectoryConvergenceTime'
    ]
    
    for col in numeric_cols_final:
        if col in df.columns:
            list_of_strings = [str(x) for x in df[col].values]
            df[col] = pd.to_numeric(list_of_strings, errors='coerce')
    
    return df


def identify_outliers(df_melted, metric_col='Metric', value_col='Value', patient_col='Patient'):
    outlier_df_list = []
    clipped_data_list = [] 
    
    CHI2_ABSOLUTE_CAP = 1e7
    NSE_ABSOLUTE_FLOOR = -5.0

    df_working = df_melted.copy()

    for method in df_working['Method'].unique():
        for metric_name in df_working['Metric'].unique(): 
            subset = df_working[(df_working['Method'] == method) & (df_working['Metric'] == metric_name)].dropna(subset=[value_col]).copy()
            if 'Chi-Squared' in metric_name:
                 subset[value_col] = np.clip(subset[value_col], None, CHI2_ABSOLUTE_CAP)
            elif 'NSE' in metric_name:
                 subset[value_col] = np.clip(subset[value_col], NSE_ABSOLUTE_FLOOR, None)
            if len(subset) < 4:
                clipped_data_list.append(subset)
                continue

            Q1 = subset[value_col].quantile(0.25)
            Q3 = subset[value_col].quantile(0.75)
            IQR = Q3 - Q1

            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            outliers = subset[
                (subset[value_col] < lower_bound) | (subset[value_col] > upper_bound)
            ].copy()

            if not outliers.empty:
                outliers['OutlierType'] = np.where(outliers[value_col] < lower_bound, 'Low', 'High')
                outliers['OriginalValue'] = outliers[value_col]
                outlier_df_list.append(outliers[['Method', 'Metric', patient_col, 'OriginalValue', 'OutlierType']])

            subset['OriginalValue'] = subset[value_col]
            subset[value_col] = np.clip(subset[value_col], lower_bound, upper_bound)

            clipped_data_list.append(subset) 

    if outlier_df_list:
        outlier_summary = pd.concat(outlier_df_list, ignore_index=True)
    else:
        cols = ['Method', 'Metric', patient_col, 'OriginalValue', 'OutlierType']
        outlier_summary = pd.DataFrame(columns=cols)

    if clipped_data_list:
        clipped_data = pd.concat(clipped_data_list, ignore_index=True)
    else:
        clipped_data = pd.DataFrame(columns=df_melted.columns)
        
    return clipped_data, outlier_summary


def plot_metrics(df_full, metrics_type='Core'):
    """Generates a 2x2 box plot for a given set of metrics (Core or Convergence)."""
    
    if metrics_type == 'Core':
        metrics_map = {
            'MASE': r'MASE (Lower is Better)',
            'Chi2': r'Chi-Squared ($\chi^2$, Lower is Better)',
            'NSE': r'NSE (Higher is Better)',
            'KGE': r'KGE (Closer to 1 is Better)',
        }
        all_metrics_keys = list(metrics_map.keys())
        file_prefix = 'core_metrics_comparison_4way'
        suptitle = 'Comparison of Core Model Fit Metrics Across Integration Methods'
    else: # Convergence/Runtime
        metrics_map = {
            'Overall_FitTime': r'Overall Fit Time (s)',
            'TrajectoryConvergenceTime': r'Trajectory Convergence Time (TCT)',
            'Total_Convergence_Runtime': r'Total Convergence Test Runtime (s)',
            'Strong_Error_Metric': r'Strong Convergence Error Metric ($\min \Delta t$)',
            'Weak_Error_Metric': r'Weak Convergence Error Metric ($\min \Delta t$)',
        }
        all_metrics_keys = ['Overall_FitTime', 'TrajectoryConvergenceTime', 'Total_Convergence_Runtime', 'Strong_Error_Metric', 'Weak_Error_Metric']
        file_prefix = 'convergence_runtime_comparison_4way'
        suptitle = 'Comparison of Model Runtime and Stability'
        
    value_vars_to_plot = []
    for col in all_metrics_keys:
        if col in df_full.columns:
            if df_full[col].count() > 0: 
                 value_vars_to_plot.append(col)

    if not value_vars_to_plot:
        print("Error: No data available to plot Convergence/Runtime metrics.")
        return

    plot_data_melted = df_full.melt(
        id_vars=['Method', 'Patient'],
        value_vars=value_vars_to_plot,
        var_name='Metric_Col',
        value_name='Value'
    )
    plot_data_melted['Metric'] = plot_data_melted['Metric_Col'].map(metrics_map)

    clipped_plot_data, outlier_summary = identify_outliers(
        plot_data_melted, metric_col='Metric_Col'
    )
    
    outlier_summary.rename(columns={'OriginalValue': 'Original Value'}, inplace=True)
    outlier_summary.to_csv(f'{file_prefix}_outlier_summary_CLIPPED.csv', index=False)
    
    file_name_clipped = f'{file_prefix}_CLIPPED_IQR.png'
    
    num_plots = len(value_vars_to_plot)
    if num_plots == 1:
        fig, axes = plt.subplots(1, 1, figsize=(7, 7))
        axes = [axes]
    elif num_plots == 2:
        fig, axes = plt.subplots(1, 2, figsize=(14, 7))
    elif num_plots == 4:
        fig, axes = plt.subplots(2, 2, figsize=(14, 12))
        axes = axes.flatten()
    else:
        num_rows = int(np.ceil(num_plots / 2.0))
        fig, axes = plt.subplots(num_rows, 2, figsize=(14, 6 * num_rows))
        axes = axes.flatten()

    unique_metrics = [metrics_map[col] for col in value_vars_to_plot]

    for i, metric in enumerate(unique_metrics):
        ax = axes[i] if num_plots > 1 else axes[0]
        subset = clipped_plot_data[clipped_plot_data['Metric'] == metric].dropna(subset=['Value'])

        sns.boxplot(x='Method', y='Value', hue='Method', data=subset, ax=ax, palette='viridis', fliersize=0, legend=False)

        ax.set_title(metric, fontsize=14)
        ax.set_ylabel('Value (Aggressively Clipped)', fontsize=12)
        ax.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
        ax.grid(axis='y', linestyle='--')

        # Add mean points
        means = subset.groupby('Method')['Value'].mean()
        x_pos = np.arange(len(means))
        ax.scatter(x_pos, means.values, marker='o', color='red', s=50, label='Mean')
        
        ax.set_xticks(np.arange(len(means)))
        ax.set_xticklabels(means.index, rotation=0)
        ax.set_xlabel('Method', fontsize=12)

    plt.suptitle(f'{suptitle} (Aggressively Clipped for Comparison)', fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(file_name_clipped)
    plt.close()
    print(f"Plot saved to '{file_name_clipped}' (Aggressively Clipped)")


def create_core_metrics_plots(df_full):
    plot_metrics(df_full, metrics_type='Core')

def create_combined_convergence_plots(df_full):
    plot_metrics(df_full, metrics_type='Convergence')



if __name__ == '__main__':
    
    all_data = load_all_data()

    analyzed_data = prepare_analyzed_data(all_data)

    create_core_metrics_plots(analyzed_data)

    create_combined_convergence_plots(analyzed_data)

    print("\n--- Final Method Counts (Verification) ---")
    print(analyzed_data['Method'].value_counts())