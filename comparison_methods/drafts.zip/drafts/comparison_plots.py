import pandas as pd
import ast
import re
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from typing import List, Dict, Any

NUMERICAL_DIR = "numericalstats"
NEURAL_DIR = "neuralstats"
PLOT_OUTPUT_DIR = "test_plots"

if not os.path.exists(PLOT_OUTPUT_DIR):
    os.makedirs(PLOT_OUTPUT_DIR)

def read_predictive_summary(file_path):
    """Reads a single predictive summary CSV file from the numerical directory."""
    full_path = os.path.join(NUMERICAL_DIR, file_path)
    try:
        df = pd.read_csv(full_path, keep_default_na=True, na_values=['', 'None', 'nan', 'NaN'])
        if 'Method' in df.columns:
             df['Method'] = df['Method'].astype(str)
        return df
    except FileNotFoundError:
        print(f"Warning: Predictive file not found: {full_path}")
        return pd.DataFrame()

def read_neuralode_results(filename="test_stats.txt"):
    """Reads NeuralODE results from the updated test_stats.txt format."""
    full_path = os.path.join(NEURAL_DIR, filename)
    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        rows = []
        block_pattern = r"Patient Patient-(\d+).*?> MASE: ([\d\.\-]+) \| Chi2: ([\d\.\-e\+]+).*?> NSE:\s+([\d\.\-]+) \| KGE:\s+([\d\.\-]+).*?> Trajectory Runtime: ([\d\.\-]+)s"
        
        for match in re.finditer(block_pattern, content, re.DOTALL):
            try:
                rows.append({
                    'Patient': int(match.group(1)),
                    'MASE': float(match.group(2)),
                    'Chi2': float(match.group(3)),
                    'NSE': float(match.group(4)),
                    'KGE': float(match.group(5)),
                    'Overall_FitTime': float(match.group(6)),
                    'Method': 'NeuralODE'
                })
            except ValueError:
                continue
        return pd.DataFrame(rows)
    except FileNotFoundError:
        print(f"Error: NeuralODE stats file not found at {full_path}")
        return pd.DataFrame()

def read_neural_convergence_log(filename="test_conv.txt"):
    """Parses the specific NeuralODE convergence log including Weak/Strong error and Runtime."""
    full_path = os.path.join(NEURAL_DIR, filename)
    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        rows = []
        pattern = r"\[Patient-(\d+)\]: Conv Time=([\d\.\-]+),.*?Weak Err=([\d\.\-e\+]+),.*?Strong Err=([\d\.\-e\+]+), Runtime=([\d\.\-]+)s"
        
        for match in re.finditer(pattern, content):
            try:
                rows.append({
                    'Patient': int(match.group(1)),
                    'TrajectoryConvergenceTime': float(match.group(2)),
                    'Weak_Error_Metric': float(match.group(3)),
                    'Strong_Error_Metric': float(match.group(4)),
                    'Total_Convergence_Runtime': float(match.group(5)),
                    'Method': 'NeuralODE'
                })
            except ValueError:
                continue
        return pd.DataFrame(rows)
    except FileNotFoundError:
        print(f"Warning: Neural convergence file not found at {full_path}")
        return pd.DataFrame()

def load_all_data():
    em_df = read_predictive_summary('em_predictive_metrics_summary.csv')
    milstein_df = read_predictive_summary('milstein_predictive_metrics_summary.csv')
    srk_df = read_predictive_summary('srk_predictive_metrics_summary.csv')
    
    neural_stats_df = read_neuralode_results('test_stats.txt')
    neural_conv_df = read_neural_convergence_log('test_conv.txt')
    
    if not neural_stats_df.empty and not neural_conv_df.empty:
        neuralode_df = pd.merge(neural_stats_df, neural_conv_df, on=['Patient', 'Method'], how='outer')
    else:
        neuralode_df = neural_stats_df if not neural_stats_df.empty else neural_conv_df
    
    dfs = [em_df, milstein_df, srk_df, neuralode_df]
    valid_dfs = [d for d in dfs if not d.empty]
    
    if not valid_dfs:
        return pd.DataFrame()
        
    return pd.concat(valid_dfs, ignore_index=True)

def prepare_analyzed_data(df):
    if df.empty: return df
    
    if 'FitTime' in df.columns: df.rename(columns={'FitTime': 'Overall_FitTime'}, inplace=True)
    if 'Runtime' in df.columns: df.rename(columns={'Runtime': 'Total_Convergence_Runtime'}, inplace=True)
    if 'StrongError' in df.columns: df.rename(columns={'StrongError': 'Strong_Error_Metric'}, inplace=True)
    if 'WeakError' in df.columns: df.rename(columns={'WeakError': 'Weak_Error_Metric'}, inplace=True)

    numeric_cols = [
        'MASE', 'Chi2', 'NSE', 'KGE', 'Overall_FitTime', 
        'Total_Convergence_Runtime', 'Strong_Error_Metric', 
        'Weak_Error_Metric', 'TrajectoryConvergenceTime'
    ]
    
    for col in numeric_cols:
        if col in df.columns:
            col_data = df[col]
            if isinstance(col_data, pd.DataFrame):
                col_data = col_data.iloc[:, 0]
            df[col] = pd.to_numeric(col_data, errors='coerce')
    
    return df

def identify_outliers(df_melted, value_col='Value'):
    clipped_data_list = [] 
    CHI2_ABSOLUTE_CAP = 1e7
    NSE_ABSOLUTE_FLOOR = -5.0

    for method in df_melted['Method'].unique():
        for metric_name in df_melted['Metric'].unique(): 
            subset = df_melted[(df_melted['Method'] == method) & (df_melted['Metric'] == metric_name)].dropna(subset=[value_col]).copy()
            
            if 'Chi-Squared' in str(metric_name):
                 subset[value_col] = np.clip(subset[value_col], None, CHI2_ABSOLUTE_CAP)
            elif 'NSE' in str(metric_name):
                 subset[value_col] = np.clip(subset[value_col], NSE_ABSOLUTE_FLOOR, None)

            if len(subset) < 4:
                clipped_data_list.append(subset)
                continue

            Q1, Q3 = subset[value_col].quantile([0.25, 0.75])
            IQR = Q3 - Q1
            lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR

            subset[value_col] = np.clip(subset[value_col], lower, upper)
            clipped_data_list.append(subset) 

    return pd.concat(clipped_data_list) if clipped_data_list else pd.DataFrame()

def plot_core_metrics(df):
    if df.empty: return
    metrics_map = {'MASE': 'MASE', 'Chi2': 'Chi-Squared', 'NSE': 'NSE', 'KGE': 'KGE'}
    cols_to_plot = [m for m in metrics_map.keys() if m in df.columns]
    
    plot_data = df.melt(id_vars=['Method', 'Patient'], value_vars=cols_to_plot, var_name='Metric_Col', value_name='Value')
    plot_data['Metric'] = plot_data['Metric_Col'].map(metrics_map)

    clipped_data = identify_outliers(plot_data)

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    for i, col in enumerate(['MASE', 'Chi2', 'NSE', 'KGE']):
        if col not in df.columns: continue
        ax = axes.flatten()[i]
        label = metrics_map[col]
        subset = clipped_data[clipped_data['Metric'] == label]
        
        sns.boxplot(x='Method', y='Value', data=subset, ax=ax, palette='viridis', fliersize=0)
        means = subset.groupby('Method')['Value'].mean()
        ax.scatter(np.arange(len(means)), means.values, marker='o', color='red', s=50, label='Mean', zorder=5)
        ax.set_title(label)
        ax.grid(axis='y', linestyle='--')

    plt.suptitle('Performance Metrics Comparison (Outliers Clipped)', fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(os.path.join(PLOT_OUTPUT_DIR, 'core_metrics_comparison.png'))
    plt.close()

def generate_performance_table(df):
    if df.empty:
        print("\n!!! NO DATA LOADED. CHECK PATHS AND FILE FORMATS !!!")
        return

    metrics = ['MASE', 'Chi2', 'NSE', 'KGE', 'Overall_FitTime', 'TrajectoryConvergenceTime', 'Strong_Error_Metric']
    available_metrics = [m for m in metrics if m in df.columns and df[m].count() > 0]
    
    summary = df.groupby('Method')[available_metrics].agg(['mean', 'std'])
    
    print("\n" + "="*110)
    print("GENERAL PERFORMANCE COMPARISON (Mean ± Std)")
    print("="*110)
    
    report_rows = []
    for method in summary.index:
        row = {'Method': method}
        for m in available_metrics:
            val = summary.loc[method, (m, 'mean')]
            std = summary.loc[method, (m, 'std')]
            if abs(val) > 1000 or (0 < abs(val) < 0.001):
                row[m] = f"{val:.2e} ± {std:.2e}"
            else:
                row[m] = f"{val:.4f} ± {std:.4f}"
        report_rows.append(row)
    
    print(pd.DataFrame(report_rows).to_string(index=False))
    
    print("\n" + "="*50)
    print("WINNER PER METRIC (Based on Mean)")
    print("="*50)
    
    means = df.groupby('Method')[available_metrics].mean()
    criteria = {
        'MASE': 'min', 'Chi2': 'min', 'NSE': 'max', 'KGE': 'max', 
        'Overall_FitTime': 'min', 'TrajectoryConvergenceTime': 'min', 'Strong_Error_Metric': 'min'
    }
    
    for m in available_metrics:
        crit = criteria.get(m, 'min')
        best_method = means[m].idxmin() if crit == 'min' else means[m].idxmax()
        best_val = means.loc[best_method, m]
        print(f"{m:28}: {best_method} ({best_val:.4e})")


if __name__ == '__main__':
    all_data = load_all_data()
    analyzed_data = prepare_analyzed_data(all_data)
    generate_performance_table(analyzed_data)
    if not analyzed_data.empty:
        plot_core_metrics(analyzed_data)
        print(f"\nBoxplots saved to '{PLOT_OUTPUT_DIR}/core_metrics_comparison.png'")