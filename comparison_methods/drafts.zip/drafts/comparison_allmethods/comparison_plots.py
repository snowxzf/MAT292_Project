import pandas as pd
import ast
import re
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def _extract_metric_from_record(record_str, metric_key):
    """Safely extracts a single float value for metrics like MASE, Chi2, FitTime."""
    # Pattern to match the key, colon, optional space, and then the numeric value
    metric_pattern = rf"'{metric_key}':\s*([+\-]?[\d\.\-e]+)[,}}]"
    match = re.search(metric_pattern, record_str)
    
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            return None
    return None

def _extract_last_array_value(record_str, metric_key):
    """
    Extracts the last floating-point number from the list/array associated with metric_key.
    This handles the content after NumPy array syntax is removed.
    """
    # Pattern to find the array/list content
    metric_pattern = rf"'{metric_key}':\s*\[\s*(.*?)\s*\]"
    match = re.search(metric_pattern, record_str, re.DOTALL)
    
    if match:
        content_str = match.group(1)
        # Find all numbers in the content string
        numbers = re.findall(r"[+\-]?[\d\.\-e]+", content_str)
        if numbers:
            try:
                # Return the last number
                return float(numbers[-1])
            except ValueError:
                return None
    return None

def _clean_content_for_regex(raw_content):
    """Standard cleaning for all convergence files."""
    cleaned = raw_content.replace('array([', '[')
    cleaned = cleaned.replace(']),', '],')
    cleaned = cleaned.replace('])}}', ']}}')
    cleaned = cleaned.replace('\n', ' ')
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

# --- 1. Data Reading Functions (Refactored) ---

def read_em_results(filename):
    """
    Reads emresults.txt which is structured as a single outer dictionary.
    Uses ast.literal_eval for performance after cleaning NumPy syntax.
    """
    try:
        with open(filename, "r") as f:
            data_str = f.read()
    except FileNotFoundError:
        print(f"Error: EM file not found at '{filename}'")
        return pd.DataFrame()

    data_str = _clean_content_for_regex(data_str)
    
    # Remove trailing junk if it exists (like ' Total runtime: ...')
    last_brace_index = data_str.rfind('}')
    if last_brace_index != -1:
        data_str = data_str[:last_brace_index + 1]

    try:
        data_dict = ast.literal_eval(data_str)
    except Exception as e:
        print(f"Error parsing EM file with ast.literal_eval: {e}")
        return pd.DataFrame()
        
    rows = []
    for patient_id, entry in data_dict.items():
        row = {'Patient': int(patient_id), 'Method': 'EM'}
        
        row['MASE'] = entry.get('MASE')
        row['Chi2'] = entry.get('Chi2')
        row['NSE'] = entry.get('NSE')
        row['KGE'] = entry.get('KGE')
        row['Overall_FitTime'] = entry.get('TrajectoryConvergenceTime')
        
        conv = entry.get("Convergence", {})
        runtime_list = conv.get('runtime')
        strong_error = conv.get('strong_error')
        weak_error = conv.get('weak_error')
        
        row['Total_Convergence_Runtime'] = runtime_list[-1] if isinstance(runtime_list, list) and runtime_list else None
        row['Strong_Error_Metric'] = strong_error[-1] if isinstance(strong_error, list) and strong_error else None
        row['Weak_Error_Metric'] = weak_error[-1] if isinstance(weak_error, list) and weak_error else None

        rows.append(row)

    return pd.DataFrame(rows)


def read_milstein_results(file_path):
    """
    Reads milstein_results.txt using regex to handle the non-dict-wrapped format.
    """
    try:
        with open(file_path, 'r') as f:
            content = f.read().strip()
    except FileNotFoundError:
        print(f"Error: Milstein file not found at '{file_path}'")
        return pd.DataFrame()
        
    content = _clean_content_for_regex(content)
    rows = []

    first_id_match = re.search(r"(\d+)\s*\{", content)
    if first_id_match:
        start_index = content.find(first_id_match.group(0))
        content = content[start_index:]
        
    last_brace_index = content.rfind('}')
    if last_brace_index != -1:
        content = content[:last_brace_index + 1]

    patient_record_pattern = r'(\d+)\s*(\{.*?\})\s*(?=\d+\s*\{|$)'
    
    for match in re.finditer(patient_record_pattern, content):
        patient_id = int(match.group(1))
        record_str = match.group(2) # The raw dictionary content for the patient (as a string)
        
        row = {'Patient': patient_id, 'Method': 'Milstein'}
        
        row['MASE'] = _extract_metric_from_record(record_str, 'MASE')
        row['Chi2'] = _extract_metric_from_record(record_str, 'Chi2')
        row['NSE'] = _extract_metric_from_record(record_str, 'NSE')
        row['KGE'] = _extract_metric_from_record(record_str, 'KGE')

        fit_time = _extract_metric_from_record(record_str, 'FitTime')
        if fit_time is None:
             fit_time = _extract_metric_from_record(record_str, 'fit_time')
             
        row['Overall_FitTime'] = fit_time
        
        row['Total_Convergence_Runtime'] = _extract_last_array_value(record_str, 'runtime')
        row['Strong_Error_Metric'] = _extract_last_array_value(record_str, 'strong_error')
        row['Weak_Error_Metric'] = _extract_last_array_value(record_str, 'weak_error')
            
        rows.append(row)
            
    return pd.DataFrame(rows)


def read_srk_results(file_path):
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return pd.DataFrame()
        
    required_metrics = ['Patient', 'MASE', 'Chi2', 'NSE', 'KGE']
    
    cols_to_use = [col for col in required_metrics if col in df.columns]
    results_df = df[cols_to_use].copy()
    
    results_df['Overall_FitTime'] = df['FitTime'] if 'FitTime' in df.columns else np.nan

    def get_last_pipe_value(col_name):
        if col_name not in df.columns:
            return np.nan
        return df[col_name].apply(
            lambda x: float(str(x).split('|')[-1]) if isinstance(x, str) and str(x).split('|')[-1].strip() else np.nan
        )

    results_df['Total_Convergence_Runtime'] = get_last_pipe_value('Runtime')
    results_df['Strong_Error_Metric'] = get_last_pipe_value('StrongError')
    results_df['Weak_Error_Metric'] = get_last_pipe_value('WeakError')

    results_df['Method'] = 'SRK'
    
    return results_df.dropna(subset=['MASE', 'Chi2', 'NSE', 'KGE'])


def load_all_data():
    # Use the corrected filenames
    em_df = read_em_results('emresults.txt')
    milstein_df = read_milstein_results('milstein_results.txt') 
    
    try:
        srk_df = read_srk_results('srk_results.csv')
    except FileNotFoundError:
        print("Warning: 'srk_results.csv' not found. Skipping SRK data.")
        srk_df = pd.DataFrame()

    return pd.concat([em_df, milstein_df, srk_df], ignore_index=True)


def prepare_analyzed_data(df):
    numeric_cols = ['MASE', 'Chi2', 'NSE', 'KGE', 'Overall_FitTime', 'Total_Convergence_Runtime', 'Strong_Error_Metric', 'Weak_Error_Metric']
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def identify_outliers(df, method_col='Method', metric_col='Metric', value_col='Value', patient_col='Patient'):
    """Identifies outliers and clips data based on 1.5*IQR rule for a single metric."""
    outlier_df_list = []
    clipped_data = pd.DataFrame()

    for method in df[method_col].unique():
        for metric_name in df[metric_col].unique():
            subset = df[(df[method_col] == method) & (df[metric_col] == metric_name)].dropna(subset=[value_col]).copy()
            
            if len(subset) < 4:
                clipped_data = pd.concat([clipped_data, subset], ignore_index=True)
                continue

            Q1 = subset[value_col].quantile(0.25)
            Q3 = subset[value_col].quantile(0.75)
            IQR = Q3 - Q1

            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            outliers = subset[
                (subset[value_col] < lower_bound) | (subset[value_col] > upper_bound)
            ].copy()

            if not outliers.empty:
                outliers['OutlierType'] = np.where(outliers[value_col] < lower_bound, 'Low', 'High')
                outliers['OriginalValue'] = outliers[value_col]
                outlier_df_list.append(outliers[[method_col, metric_col, patient_col, 'OriginalValue', 'OutlierType']])

            subset['OriginalValue'] = subset[value_col]
            subset[value_col] = np.clip(subset[value_col], lower_bound, upper_bound)

            clipped_data = pd.concat([clipped_data, subset], ignore_index=True)

    outlier_summary = pd.concat(outlier_df_list, ignore_index=True)
    return clipped_data, outlier_summary


def create_combined_convergence_plots(df, file_name):
    """Generates a single 2x2 box plot for the four convergence metrics."""
    
    metrics_map = {
        'Overall_FitTime': 'Overall Fit Time / TCT (s)',
        'Total_Convergence_Runtime': 'Total Convergence Test Runtime (s)',
        'Strong_Error_Metric': 'Strong Convergence Error Metric (min $\\Delta t$)',
        'Weak_Error_Metric': 'Weak Convergence Error Metric (min $\\Delta t$)',
    }
    
    # 1. Melt the data
    plot_data = df.melt(
        id_vars=['Method', 'Patient'],
        value_vars=metrics_map.keys(),
        var_name='Metric_Col',
        value_name='Value'
    )
    plot_data['Metric'] = plot_data['Metric_Col'].map(metrics_map)
    plot_data.drop(columns=['Metric_Col'], inplace=True)

    # 2. Identify and clip outliers
    clipped_plot_data, outlier_summary = identify_outliers(
        plot_data, metric_col='Metric'
    )
    
    # Save the outlier summary
    combined_outliers = outlier_summary
    combined_outliers.rename(columns={'OriginalValue': 'Original Value'}, inplace=True)
    combined_outliers.to_csv('combined_convergence_outlier_summary_2x2.csv', index=False)
    print("\n--- Combined Convergence Metrics Outlier Summary (All Methods) ---")
    print("Summary saved to 'combined_convergence_outlier_summary_2x2.csv'")
    
    # 3. Create 2x2 plot
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    axes = axes.flatten()
    unique_metrics = list(metrics_map.values())

    for i, metric in enumerate(unique_metrics):
        ax = axes[i]
        subset = clipped_plot_data[clipped_plot_data['Metric'] == metric].dropna(subset=['Value'])

        sns.boxplot(x='Method', y='Value', data=subset, ax=ax, palette='viridis', fliersize=0)

        ax.set_title(metric, fontsize=14)
        ax.set_ylabel('Value', fontsize=12)
        ax.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
        ax.grid(axis='y', linestyle='--')

        means = subset.groupby('Method')['Value'].mean()
        x_pos = np.arange(len(means))
        ax.scatter(x_pos, means.values, marker='o', color='red', s=50, label='Mean')
        
        ax.set_xticks(np.arange(len(means)))
        ax.set_xticklabels(means.index, rotation=0)
        ax.set_xlabel('Method', fontsize=12)

    plt.suptitle('Comparison of Convergence Metrics Across Integration Methods (Outliers Clipped)', fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(file_name)
    plt.close()
    print(f"Combined 2x2 box plots saved to '{file_name}' (Outliers Clipped)")


if __name__ == '__main__':
    
    all_data = load_all_data()
    analyzed_data = prepare_analyzed_data(all_data)
    create_combined_convergence_plots(analyzed_data, 'convergence_comparison_2x2_final.png')